package com.partition.partitionCalculation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PartitionCalculationApplication {

	public static void main(String[] args) {
		
		/*
		 * Partition<String> p = new Partition<String>(); int chunk = 2; List<String>
		 * list = new ArrayList<String>(Arrays.asList("Paul", "David", "Lisa", "Alyssa",
		 * "Alex", "Ronald", "Todd", "Hope")); System.out.println(p.split(list, chunk));
		 */
		
		SpringApplication.run(PartitionCalculationApplication.class, args);
	}

}
